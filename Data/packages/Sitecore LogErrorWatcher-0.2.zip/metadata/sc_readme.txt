Just install with override.

Let smar know if you experience any problems.