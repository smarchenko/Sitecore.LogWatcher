Just install with override.

Let smar know if you experience any problems.

New in this release:
- I have added own log viewer application. Just click on the icon to see new menu command.